# Download ATAC-seq from TAC study
/hpc/home/imk11/src/IMKHeartEnhancerScripts/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE154518 SRR12232081
/hpc/home/imk11/src/IMKHeartEnhancerScripts/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE154518 SRR12232082
/hpc/home/imk11/src/IMKHeartEnhancerScripts/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE154518 SRR12232083
/hpc/home/imk11/src/IMKHeartEnhancerScripts/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE154518 SRR12232087
/hpc/home/imk11/src/IMKHeartEnhancerScripts/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE154518 SRR12232088
/hpc/home/imk11/src/IMKHeartEnhancerScripts/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE154518 SRR12232089
/hpc/home/imk11/src/IMKHeartEnhancerScripts/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE154518 SRR12232084
/hpc/home/imk11/src/IMKHeartEnhancerScripts/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE154518 SRR12232085
/hpc/home/imk11/src/IMKHeartEnhancerScripts/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE154518 SRR12232086

# Process the ATAC-seq from the TAC study
sbatch -p common -J TACControl -t 3-0 --mem 1999M --export=ALL --wrap "caper hpc submit /hpc/home/imk11/atac-seq-pipeline/atac.wdl -i /hpc/group/gersbachlab/imk11/GSE154518/Control/TAC_Control.json --leader-job-name TACControlL --singularity"
sbatch -p common -J TACThreeDays -t 3-0 --mem 1999M --export=ALL --wrap "caper hpc submit /hpc/home/imk11/atac-seq-pipeline/atac.wdl -i /hpc/group/gersbachlab/imk11/GSE154518/TACThreeDays/TAC_ThreeDays.json --leader-job-name TACThreeDaysL --singularity"
sbatch -p common -J TACThreeWeeks -t 3-0 --mem 1999M --export=ALL --wrap "caper hpc submit /hpc/home/imk11/atac-seq-pipeline/atac.wdl -i /hpc/group/gersbachlab/imk11/GSE154518/TACThreeWeeks/TAC_ThreeWeeks.json --leader-job-name TACThreeWeeksL --singularity"

# Process the ATAC-seq data from the cardiac transcription factor study
sbatch -p common -J TACControl -t 3-0 --mem 1999M --export=ALL --wrap "caper hpc submit /hpc/home/imk11/atac-seq-pipeline/atac.wdl -i /hpc/group/gersbachlab/imk11/GSE124008/ATAC/MouseE12.5VentricleATAC.json --leader-job-name FATAC --singularity"
