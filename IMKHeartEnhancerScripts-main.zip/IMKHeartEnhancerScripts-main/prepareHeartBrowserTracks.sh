# Prepare DCM versus non-failure
/hpc/home/imk11/src/UCSCUtils/bigWigToBedGraph /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_DCM_merged.RPKM.bigwig /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_DCM_merged.RPKM.bedGraph
/hpc/group/gersbachlab/imk11/UCSCUtils/bigWigToBedGraph /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_NF_merged.RPKM.bigwig /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_NF_merged.RPKM.bedGraph
/hpc/group/gersbachlab/imk11/UCSCUtils/liftOver /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_DCM_merged.RPKM.bedGraph /hpc/group/gersbachlab/imk11/LiftoverChains/hg19ToHg38.over.chain.gz /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_DCM_merged.RPKM_hg38.bedGraph /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_DCM_merged.RPKM_unmapped.bedGraph
/hpc/group/gersbachlab/imk11/UCSCUtils/liftOver /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_NF_merged.RPKM.bedGraph /hpc/group/gersbachlab/imk11/LiftoverChains/hg19ToHg38.over.chain.gz /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_NF_merged.RPKM_hg38.bedGraph /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_NF_merged.RPKM_unmapped.bedGraph
gzip /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_DCM_merged.RPKM.bedGraph
gzip /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_NF_merged.RPKM.bedGraph
gzip /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_DCM_merged.RPKM_hg38.bedGraph
gzip /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_NF_merged.RPKM_hg38.bedGraph
zcat /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_DCM_merged.RPKM_hg38.bedGraph.gz | grep chr14 | gzip > /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_DCM_merged.RPKM_hg38_chr14.bedGraph.gz
zcat /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_NF_merged.RPKM_hg38.bedGraph.gz | grep chr14 | gzip > /hpc/group/gersbachlab/imk11/GSE165303/GSE165303_atacseq_NF_merged.RPKM_hg38_chr14.bedGraph.gz

# Prepare left and right ventricle
/hpc/group/gersbachlab/imk11/UCSCUtils/bigWigToBedGraph /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/RightVentricle/atac/75055828-6c86-4521-95d5-282ee459dcf7/call-macs2_signal_track_pooled/execution/glob-8876d8ced974dc46a0c7a4fac20a3a95/rep.pooled.fc.signal.bigwig /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/RightVentricle/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph
/hpc/group/gersbachlab/imk11/UCSCUtils/bigWigToBedGraph /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/LeftVentricle/atac/f33c25ae-864d-42c9-a74e-80cf301d3d0c/call-macs2_signal_track_pooled/execution/glob-8876d8ced974dc46a0c7a4fac20a3a95/rep.pooled.fc.signal.bigwig /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/LeftVentricle/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph
gzip /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/RightVentricle/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph
gzip /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/LeftVentricle/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph
zcat /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/RightVentricle/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph.gz | grep chr14 | gzip > /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/RightVentricle/atac/signal/pooled-rep/rep.pooled.fc.signal_chr14.bedGraph.gz
zcat /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/LeftVentricle/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph.gz | grep chr14 | gzip > /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/LeftVentricle/atac/signal/pooled-rep/rep.pooled.fc.signal_chr14.bedGraph.gz

# Prepare left ventricle embryo
/hpc/group/gersbachlab/imk11/UCSCUtils/bigWigToBedGraph /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/LeftVentricleEmbryo/atac/7596f063-3838-48c5-9b7a-9af5f3cba851/call-macs2_signal_track_pooled/execution/rep.pooled.fc.signal.bigwig /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/LeftVentricleEmbryo/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph
gzip /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/LeftVentricleEmbryo/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph
zcat /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/LeftVentricleEmbryo/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph | grep chr14 | gzip > /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/LeftVentricleEmbryo/atac/signal/pooled-rep/rep.pooled.fc.signal_chr14.bedGraph.gz

# Prepare mouse non-TAC versus TAC
/hpc/group/gersbachlab/imk11/UCSCUtils/bigWigToBedGraph /hpc/group/gersbachlab/imk11/GSE154518/Control/atac/signal/pooled-rep/rep.pooled.fc.signal.bigwig /hpc/group/gersbachlab/imk11/GSE154518/Control/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph
/hpc/group/gersbachlab/imk11/UCSCUtils/bigWigToBedGraph /hpc/group/gersbachlab/imk11/GSE154518/TACThreeWeeks/atac/signal/pooled-rep/rep.pooled.fc.signal.bigwig /hpc/group/gersbachlab/imk11/GSE154518/TACThreeWeeks/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph
gzip /hpc/group/gersbachlab/imk11/GSE154518/Control/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph
gzip /hpc/group/gersbachlab/imk11/GSE154518/TACThreeWeeks/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph
zcat /hpc/group/gersbachlab/imk11/GSE154518/Control/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph.gz | grep chr14 | gzip > /hpc/group/gersbachlab/imk11/GSE154518/Control/atac/signal/pooled-rep/rep.pooled.fc.signal_chr14.bedGraph.gz
zcat /hpc/group/gersbachlab/imk11/GSE154518/TACThreeWeeks/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph.gz | grep chr14 | gzip > /hpc/group/gersbachlab/imk11/GSE154518/TACThreeWeeks/atac/signal/pooled-rep/rep.pooled.fc.signal_chr14.bedGraph.gz

# Prepare mouse ventricle embryo
/hpc/group/gersbachlab/imk11/UCSCUtils/bigWigToBedGraph /hpc/group/gersbachlab/imk11/GSE124008/ATAC/atac/signal/pooled-rep/rep.pooled.fc.signal.bigwig /hpc/group/gersbachlab/imk11/GSE124008/ATAC/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph
gzip /hpc/group/gersbachlab/imk11/GSE124008/ATAC/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph
zcat /hpc/group/gersbachlab/imk11/GSE124008/ATAC/atac/signal/pooled-rep/rep.pooled.fc.signal.bedGraph.gz | grep chr14 | gzip > /hpc/group/gersbachlab/imk11/GSE124008/ATAC/atac/signal/pooled-rep/rep.pooled.fc.signal_chr14.bedGraph.gz

# Prepare mouse cardiac transcription factor data
/hpc/group/gersbachlab/imk11/UCSCUtils/bigWigToBedGraph /hpc/group/gersbachlab/imk11/GSE124008/Tead1/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bigwig /hpc/group/gersbachlab/imk11/GSE124008/Tead1/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bedGraph
/hpc/group/gersbachlab/imk11/UCSCUtils/bigWigToBedGraph /hpc/group/gersbachlab/imk11/GSE124008/Tead1Adult/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bigwig /hpc/group/gersbachlab/imk11/GSE124008/Tead1Adult/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bedGraph
/hpc/group/gersbachlab/imk11/UCSCUtils/bigWigToBedGraph /hpc/group/gersbachlab/imk11/GSE124008/SrfAdult/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bigwig /hpc/group/gersbachlab/imk11/GSE124008/SrfAdult/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bedGraph
/hpc/group/gersbachlab/imk11/UCSCUtils/bigWigToBedGraph /hpc/group/gersbachlab/imk11/GSE124008/Nkx2.5Adult/chip/signal/rep2/SRR8335347.srt.nodup_x_ctl.pooled.fc.signal.bigwig /hpc/group/gersbachlab/imk11/GSE124008/Nkx2.5Adult/chip/signal/rep2/SRR8335347.srt.nodup_x_ctl.pooled.fc.signal.bedGraph
/hpc/group/gersbachlab/imk11/UCSCUtils/bigWigToBedGraph /hpc/group/gersbachlab/imk11/GSE73368/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bigwig /hpc/group/gersbachlab/imk11/GSE73368/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bedGraph
/hpc/group/gersbachlab/imk11/UCSCUtils/bigWigToBedGraph /hpc/group/gersbachlab/imk11/GSE21529/Nkx2.5/chip/signal/rep1/SRR058584.merged.srt.nodup_x_SRR058572.merged.srt.nodup.fc.signal.bigwig /hpc/group/gersbachlab/imk11/GSE21529/Nkx2.5/chip/signal/rep1/SRR058584.merged.srt.nodup_x_SRR058572.merged.srt.nodup.fc.signal.bedGraph
gzip /hpc/group/gersbachlab/imk11/GSE124008/Tead1/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bedGraph
gzip /hpc/group/gersbachlab/imk11/GSE124008/Tead1Adult/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bedGraph
gzip /hpc/group/gersbachlab/imk11/GSE124008/SrfAdult/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bedGraph
gzip /hpc/group/gersbachlab/imk11/GSE124008/Nkx2.5Adult/chip/signal/rep2/SRR8335347.srt.nodup_x_ctl.pooled.fc.signal.bedGraph
gzip /hpc/group/gersbachlab/imk11/GSE73368/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bedGraph
gzip /hpc/group/gersbachlab/imk11/GSE21529/Nkx2.5/chip/signal/rep1/SRR058584.merged.srt.nodup_x_SRR058572.merged.srt.nodup.fc.signal.bedGraph
zcat /hpc/group/gersbachlab/imk11/GSE124008/Tead1/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bedGraph.gz | grep chr14 | gzip > /hpc/group/gersbachlab/imk11/GSE124008/Tead1/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal_chr14.bedGraph.gz
zcat /hpc/group/gersbachlab/imk11/GSE124008/Tead1Adult/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bedGraph.gz | grep chr14 | gzip > /hpc/group/gersbachlab/imk11/GSE124008/Tead1Adult/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal_chr14.bedGraph.gz
zcat /hpc/group/gersbachlab/imk11/GSE124008/SrfAdult/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bedGraph.gz | grep chr14 | gzip > /hpc/group/gersbachlab/imk11/GSE124008/SrfAdult/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal_chr14.bedGraph.gz
zcat /hpc/group/gersbachlab/imk11/GSE73368/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal.bedGraph.gz | grep chr14 | gzip > /hpc/group/gersbachlab/imk11/GSE73368/chip/signal/pooled-rep/rep.pooled_x_ctl.pooled.fc.signal_chr14.bedGraph.gz
zcat /hpc/group/gersbachlab/imk11/GSE21529/Nkx2.5/chip/signal/rep1/SRR058584.merged.srt.nodup_x_SRR058572.merged.srt.nodup.fc.signal.bedGraph.gz | grep chr14 | gzip > /hpc/group/gersbachlab/imk11/GSE21529/Nkx2.5/chip/signal/rep1/SRR058584.merged.srt.nodup_x_SRR058572.merged.srt.nodup.fc.signal_chr14.bedGraph.gz
zcat /hpc/group/gersbachlab/imk11/GSE124008/Nkx2.5Adult/chip/signal/rep2/SRR8335347.srt.nodup_x_ctl.pooled.fc.signal.bedGraph.gz | grep chr14 | gzip > /hpc/group/gersbachlab/imk11/GSE124008/Nkx2.5Adult/chip/signal/rep2/SRR8335347.srt.nodup_x_ctl.pooled.fc.signal_chr14.bedGraph.gz
