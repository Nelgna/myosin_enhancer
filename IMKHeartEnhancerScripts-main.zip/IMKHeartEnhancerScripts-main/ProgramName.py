import sys
import os

def get():
  return os.path.basename(sys.argv[0])

