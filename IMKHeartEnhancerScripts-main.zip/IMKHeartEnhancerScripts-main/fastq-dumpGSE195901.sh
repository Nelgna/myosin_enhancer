/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE195901 SRR17846995
/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE195901 SRR17846994
/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE195901 SRR17846983
/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE195901 SRR17846982
