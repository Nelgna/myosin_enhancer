#!/bin/bash

Filename='/hpc/home/imk11/src/IMKHeartEnhancerScripts/fastq-dumpGSE124008.sh'
Ouptprefix='/hpc/home/imk11/src/fastq-dumpGSE124008S'
Name='fastq-dumpGSE124008S'
Queue='common'
Count=0
while read line;
do
        Count=$((Count+1));
        Outfilename=$Ouptprefix$Count".sh";
        echo "#!/bin/bash
#SBATCH -p $Queue
#SBATCH --job-name=$Name$Count
#SBATCH --mem=8G
#SBATCH --time=4:00:00
#SBATCH -o $Ouptprefix$Count.o
#SBATCH -e $Ouptprefix$Count.e
$line" >  $Outfilename;
        command1="sbatch ";
        command2=$Outfilename;
        $command1$command2;
        sleep .2
done < $Filename
