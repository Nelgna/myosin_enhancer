# Download mouse heart ChIP-seq
/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE73368 SRR2503203
/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE73368 SRR2503205
/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE73368 SRR2503204
/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE73368 SRR2503206
sh /hpc/home/imk11/src/IMKHeartEnhancerScripts/fastq-dumpGSE124008.sh

# Download HL-1 cell ChIP-seq
sh /hpc/home/imk11/src/IMKHeartEnhancerScripts/fastq-dumpGSE21529.sh

# Process mouse heart ChIP-seq
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE73368/MouseE10.5Hand2.json --singularity --leader-job-name Hand2
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE124008/Mef2a/MouseE12.5VentricleMef2a.json --singularity --leader-job-name Mef2a
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE124008/Mef2c/MouseE12.5VentricleMef2c.json --singularity --leader-job-name Mef2c
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE124008/Nkx2.5/MouseE12.5VentricleNkx2.5.json --singularity --leader-job-name Nkx2.5
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE124008/Srf/MouseE12.5VentricleSrf.json --singularity --leader-job-name Srf
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE124008/Tbx5/MouseE12.5VentricleTbx5.json --singularity --leader-job-name Tbx5
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE124008/Tead1/MouseE12.5VentricleTead1.json --singularity --leader-job-name Tead1
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE124008/Mef2aAdult/MouseP42VentricleMef2a.json --singularity --leader-job-name AMef2a
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE124008/Nkx2.5Adult/MouseP42VentricleNkx2.5.json --singularity --leader-job-name ANkx2.5
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE124008/SrfAdult/MouseP42VentricleSrf.json --singularity --leader-job-name ASrf
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE124008/Tbx5Adult/MouseP42VentricleTbx5.json --singularity --leader-job-name ATbx5
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE124008/Tead1Adult/MouseP42VentricleTead1.json --singularity --leader-job-name ATead1
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE195901/P300/MouseE12.5VentricleP300.json --singularity --leader-job-name P300
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE195901/P300Adult/MouseP42VentricleP300.json --singularity --leader-job-name AP300

# Process HL-1 cell ChIP-seq
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE21529/Gata4/HL1Gata4.json --singularity --leader-job-name HGata4
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE21529/Mef2a/HL1Mef2a.json --singularity --leader-job-name HMef2a
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE21529/Nkx2.5/HL1Nkx2.5.json --singularity --leader-job-name HNkx2.5
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE21529/Srf/HL1Srf.json --singularity --leader-job-name HSrf
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE21529/Tbx5/HL1Tbx5.json --singularity --leader-job-name HTbx5
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE21529/P300/HL1P300.json --singularity --leader-job-name HP300
