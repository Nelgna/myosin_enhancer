# Process ENCODE heart DNase
sbatch -p common -J RightVentricle -t 2-0 --mem 1999M --export=ALL --wrap "caper hpc submit /hpc/home/imk11/atac-seq-pipeline/atac.wdl -i /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/RightVentricle/RightVentricle.json --leader-job-name RightVentricleL --singularity"
sbatch -p common -J LeftVentricle -t 2-0 --mem 1999M --export=ALL --wrap "caper hpc submit /hpc/home/imk11/atac-seq-pipeline/atac.wdl -i /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/LeftVentricle/LeftVentricle.json --leader-job-name LeftVentricleL --singularity"

# Process ENCODE liver DNase
sbatch -p common -J Liver -t 2-0 --mem 1999M --export=ALL --wrap "caper hpc submit /hpc/home/imk11/atac-seq-pipeline/atac.wdl -i /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/Liver/Liver.json --leader-job-name LiverL --singularity"

# Process ENCODE skeletal muscle DNase
sbatch -p common -J SkeletalMuscle -t 2-0 --mem 1999M --export=ALL --wrap "caper hpc submit /hpc/home/imk11/atac-seq-pipeline/atac.wdl -i /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/SkeletalMuscle/SkeletalMuscle.json --leader-job-name SkeletalMuscleL --singularity"
sbatch -p common -J SkeletalMuscle_GoodReps -t 2-0 --mem 1999M --export=ALL --wrap "caper hpc submit /hpc/home/imk11/atac-seq-pipeline/atac.wdl -i /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/SkeletalMuscle_GoodReps/SkeletalMuscle_GoodReps.json --leader-job-name SkeletalMuscleGoodRepsL --singularity"

# Process ENCODE left ventricle embryo
sbatch -p common -J LeftVentricleEmbryo -t 2-0 --mem 1999M --export=ALL --wrap "caper hpc submit /hpc/home/imk11/atac-seq-pipeline/atac.wdl -i /hpc/group/gersbachlab/imk11/ENCODEHumanDNase/LeftVentricleEmbryo/LeftVentricleEmbryo.json --leader-job-name LeftVentricleEmbryoL --singularity"
