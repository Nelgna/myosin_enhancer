# Download human ChIP-seq data
/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE81585 SRR3618794
/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE81585 SRR3618795
/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE81585 SRR3618796
/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE116862 SRR7506639
/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE116862 SRR7506640
/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE116862 SRR7506661
/hpc/home/imk11/src/sratoolkit.3.1.1-centos_linux64/bin/fastq-dump --split-3 --gzip -O /hpc/group/gersbachlab/imk11/GSE116862 SRR7506651

# Process the human ChIP-seq data
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE81585/HEY2/CM_HEY2.json --singularity --leader-job-name HEY2
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE81585/TBX5/CM_TBX5.json --singularity --leader-job-name TBX5
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE81585/NR2F2/CM_NR2F2.json --singularity --leader-job-name NR2F2
caper hpc submit /hpc/home/imk11/chip-seq-pipeline2/chip.wdl -i /hpc/group/gersbachlab/imk11/GSE116862/CTCF/CM_CTCF.json --singularity --leader-job-name CTCF
